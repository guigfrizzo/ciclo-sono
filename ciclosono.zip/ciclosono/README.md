Sleep Cycle
Sleep Cycle é um aplicativo web simples que ajuda a calcular os melhores horários para dormir e acordar, com base em ciclos de sono de aproximadamente 90 minutos.

Como Funciona
Calculadora Bidirecional:

Informe seu horário de dormir para saber quando acordar ou,

Escolha o horário que deseja acordar para descobrir quando ir para a cama.

Ciclos de Sono:

Calcula 4, 5 ou 6 ciclos completos de sono (aproximadamente 6, 7,5 ou 9 horas).

Interface Simples:

Design intuitivo com elementos visuais leves e fáceis de usar.

Informações Básicas:

Explicação sobre os diferentes estágios do sono e como os ciclos funcionam.

Sobre o Projeto
Um projeto prático para ajudar pessoas a ajustar seus horários de sono sem complicações.

Contribuição
Contribuições são bem-vindas! Sinta-se à vontade para abrir uma issue ou enviar um pull request com sugestões e melhorias.

Licença
Este projeto é licenciado sob a MIT License.


Para fazer funcionar Voce precisa alterar o .env (Onde fica as credenciais do meu banco de dados) para as credenciais do SEU banco de dados, após definir nome e etc, use a query abaixo no phpmyadmin para poder rodar a aplicação:


-- Criar tabela users
CREATE TABLE `users` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `email_verified_at` TIMESTAMP NULL,
    `password` VARCHAR(255) NOT NULL,
    `remember_token` VARCHAR(100) NULL,
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    PRIMARY KEY (`id`)
);

-- Criar tabela password_reset_tokens
CREATE TABLE `password_reset_tokens` (
    `email` VARCHAR(255),
    `token` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP NULL,
    PRIMARY KEY (`email`)
);

-- Criar tabela sessions
CREATE TABLE `sessions` (
    `id` VARCHAR(255),
    `user_id` BIGINT UNSIGNED NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` TEXT NULL,
    `payload` TEXT NOT NULL,
    `last_activity` INT NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `sessions_user_id_index` (`user_id`),
    INDEX `sessions_last_activity_index` (`last_activity`)
);

-- Criar tabela cache
CREATE TABLE `cache` (
    `key` VARCHAR(255),
    `value` MEDIUMTEXT NOT NULL,
    `expiration` INT NOT NULL,
    PRIMARY KEY (`key`)
);

-- Criar tabela cache_locks
CREATE TABLE `cache_locks` (
    `key` VARCHAR(255),
    `owner` VARCHAR(255) NOT NULL,
    `expiration` INT NOT NULL,
    PRIMARY KEY (`key`)
);

-- Criar tabela jobs
CREATE TABLE `jobs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT,
    `queue` VARCHAR(255) NOT NULL,
    `payload` LONGTEXT NOT NULL,
    `attempts` TINYINT UNSIGNED NOT NULL,
    `reserved_at` INT UNSIGNED NULL,
    `available_at` INT UNSIGNED NOT NULL,
    `created_at` INT UNSIGNED NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `jobs_queue_index` (`queue`)
);

-- Criar tabela job_batches
CREATE TABLE `job_batches` (
    `id` VARCHAR(255),
    `name` VARCHAR(255) NOT NULL,
    `total_jobs` INT NOT NULL,
    `pending_jobs` INT NOT NULL,
    `failed_jobs` INT NOT NULL,
    `failed_job_ids` LONGTEXT NOT NULL,
    `options` MEDIUMTEXT NULL,
    `cancelled_at` INT NULL,
    `created_at` INT NOT NULL,
    `finished_at` INT NULL,
    PRIMARY KEY (`id`)
);

-- Criar tabela failed_jobs
CREATE TABLE `failed_jobs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT,
    `uuid` VARCHAR(255) NOT NULL UNIQUE,
    `connection` TEXT NOT NULL,
    `queue` TEXT NOT NULL,
    `payload` LONGTEXT NOT NULL,
    `exception` LONGTEXT NOT NULL,
    `failed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);


para executar o projeto é necessário rodar composer install para instalar as dependências

