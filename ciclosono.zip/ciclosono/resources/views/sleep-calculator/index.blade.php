<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sleep Cycle - A better rest means a better day</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <style>
        body {
            margin: auto;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            overflow: auto;
            background: linear-gradient(315deg, rgba(101,0,94,1) 3%, rgba(60,132,206,1) 38%, rgba(60,132,206,1) 68%, rgba(101,0,94,1) 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 30s -15s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }

        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 45s linear reverse infinite;
            opacity: 0.8;
        }

        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 60s -1s reverse infinite;
            opacity: 0.9;
        }

        @keyframes wave {
            2% {
                transform: translateX(1);
            }
            25% {
                transform: translateX(-25%);
            }
            50% {
                transform: translateX(-50%);
            }
            75% {
                transform: translateX(-25%);
            }
            100% {
                transform: translateX(1);
            }
        }

        .modal-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            z-index: 40;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .modal-backdrop.show {
            opacity: 1;
        }

        .modal-side {
            position: fixed;
            top: 0;
            right: -100%;
            width: 90%;
            max-width: 500px;
            height: 100%;
            background: white;
            z-index: 50;
            transition: right 0.3s ease;
            overflow-y: auto;
        }

        .modal-side.show {
            right: 0;
        }
    </style>
</head>
<body>
    <!-- Background waves -->
    <div class="wave"></div>
    <div class="wave"></div>
    <div class="wave"></div>

    <div id="app">
        <!-- Navbar -->
        <nav class="bg-purple-600/80 shadow-lg backdrop-blur-sm">
            <div class="container mx-auto px-4">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center">
                        <svg class="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                        </svg>
                        <div class="ml-4">
                            <span class="text-white text-lg font-semibold">Sleep Cycle</span>
                            <p class="text-purple-200 text-sm">A better rest means a better day</p>
                        </div>
                    </div>
                    <button @click="showModal = true" 
                        class="text-white hover:text-purple-200 transition-colors duration-200 text-sm">
                        Por que o ciclo do sono é importante?
                    </button>
                </div>
            </div>
        </nav>

        <!-- Modal -->
        <div v-if="showModal" @click="showModal = false" class="modal-backdrop" :class="{ 'show': showModal }"></div>
        <div class="modal-side" :class="{ 'show': showModal }">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-purple-600">Por que o ciclo do sono é importante?</h2>
                    <button @click="showModal = false" class="text-gray-500 hover:text-gray-700">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
                <div class="prose prose-purple">
                    <p class="mb-4">O ciclo do sono é fundamental para nossa saúde física e mental. Durante o sono, nosso corpo passa por diferentes estágios, cada um com funções específicas e importantes:</p>
                    
                    <h3 class="text-lg font-semibold mt-4 mb-2">Os 4 Estágios do Sono</h3>
                    <ul class="list-disc pl-5 space-y-2">
                        <li><strong>Estágio 1 (N1):</strong> Sonolência leve, facilmente despertável</li>
                        <li><strong>Estágio 2 (N2):</strong> Sono leve, temperatura corporal diminui</li>
                        <li><strong>Estágio 3 (N3):</strong> Sono profundo, recuperação física</li>
                        <li><strong>REM:</strong> Sono dos sonhos, consolidação da memória</li>
                    </ul>

                    <h3 class="text-lg font-semibold mt-6 mb-2">Benefícios de um Bom Ciclo do Sono</h3>
                    <ul class="list-disc pl-5 space-y-2">
                        <li>Melhor memória e capacidade de aprendizado</li>
                        <li>Sistema imunológico mais forte</li>
                        <li>Regulação do humor e redução do estresse</li>
                        <li>Maior energia e produtividade</li>
                        <li>Melhor controle do peso e metabolismo</li>
                    </ul>

                    <div class="mt-6 p-4 bg-purple-100 border-l-4 border-purple-600 rounded-r-lg">
                        <p class="text-purple-900 font-medium">
                            ⭐ Cada ciclo completo dura aproximadamente <span class="font-bold">90 minutos</span>, e é importante completar ciclos inteiros para acordar se sentindo mais disposto. Por isso, nossa calculadora ajuda você a programar seus horários de sono para acordar no momento ideal do ciclo!
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mx-auto px-4 py-8">
            <div class="max-w-2xl mx-auto">
                <h1 class="text-3xl font-bold text-center mb-8 text-white">Calculadora de Ciclo do Sono</h1>
                
                <div class="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6 mb-8">
                    <div class="mb-6">
                        <h2 class="text-xl font-semibold mb-4">Calcular horário de Dormir</h2>
                        <div class="flex flex-col gap-2">
                            <label for="bedtime" class="text-sm text-gray-600">Que horas você quer dormir?</label>
                            <div class="flex gap-4">
                                <input type="time" 
                                    id="bedtime"
                                    v-model="bedtime" 
                                    :disabled="disableBedtime"
                                    @focus="disableWakeupTime = true"
                                    @blur="disableWakeupTime = false"
                                    class="border rounded px-3 py-2 flex-grow text-lg focus:ring-2 focus:ring-purple-600 focus:border-purple-600 focus:outline-none"
                                    placeholder="00:00">
                                <button @click="calculateFromBedtime" 
                                    class="bg-purple-600 text-white px-6 py-2 rounded hover:bg-purple-700 transition-colors duration-200">
                                    Calcular
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="mb-6">
                        <h2 class="text-xl font-semibold mb-4">Calcular horário de Acordar</h2>
                        <div class="flex flex-col gap-2">
                            <label for="wakeupTime" class="text-sm text-gray-600">Que horas você vai acordar?</label>
                            <div class="flex gap-4">
                                <input type="time" 
                                    id="wakeupTime"
                                    v-model="wakeupTime" 
                                    :disabled="disableWakeupTime"
                                    @focus="disableBedtime = true"
                                    @blur="disableBedtime = false"
                                    class="border rounded px-3 py-2 flex-grow text-lg focus:ring-2 focus:ring-purple-600 focus:border-purple-600 focus:outline-none"
                                    placeholder="00:00">
                                <button @click="calculateFromWakeup" 
                                    class="bg-purple-600 text-white px-6 py-2 rounded hover:bg-purple-700 transition-colors duration-200">
                                    Calcular
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Resultados -->
                <div v-if="results.length > 0" class="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6">
                    <h2 class="text-xl font-semibold mb-4">Resultados</h2>
                    <div class="space-y-4">
                        <div v-for="(result, index) in results" :key="index" 
                             class="p-4 border rounded-lg hover:bg-white/80">
                            <div class="flex justify-between items-center">
                                <div>
                                    <p class="text-lg font-medium">@{{ result.time }}</p>
                                    <p class="text-sm text-gray-600">@{{ result.cycles }} ciclos (@{{ result.total_hours }} horas)</p>
                                </div>
                                <div class="text-sm text-gray-500">
                                    Qualidade do sono: 
                                    <span :class="{'text-green-600': result.cycles >= 5, 'text-yellow-600': result.cycles == 4}">
                                        @{{ result.cycles >= 5 ? 'Ótima' : 'Boa' }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Dicas de sono -->
                <div class="mt-8 bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6">
                    <h2 class="text-xl font-semibold mb-4">Dicas para um Sono Melhor</h2>
                    <ul class="list-disc pl-6 space-y-2 text-gray-700">
                        <li>Mantenha o ambiente escuro e silencioso</li>
                        <li>Evite telas (celular, computador) 1 hora antes de dormir</li>
                        <li>Mantenha uma temperatura agradável no quarto</li>
                        <li>Evite cafeína nas últimas 6 horas antes de dormir</li>
                        <li>Mantenha um horário regular para dormir e acordar</li>
                    </ul>
                </div>
            </div>
        </div>

        <script>
            const { createApp } = Vue

            createApp({
                data() {
                    return {
                        bedtime: '',
                        wakeupTime: '',
                        results: [],
                        showModal: false,
                        recommendations: [],
                        disableBedtime: false,
                        disableWakeupTime: false
                    }
                },
                methods: {
                    async calculateFromBedtime() {
                        try {
                            const response = await axios.post('/calculate-from-bedtime', {
                                bedtime: this.bedtime
                            });
                            this.results = response.data.wakeup_times;
                        } catch (error) {
                            console.error('Erro ao calcular:', error);
                        }
                    },
                    async calculateFromWakeup() {
                        try {
                            const response = await axios.post('/calculate-from-wakeup', {
                                wakeup_time: this.wakeupTime
                            });
                            this.results = response.data.bedtimes;
                        } catch (error) {
                            console.error('Erro ao calcular:', error);
                        }
                    },
                    async fetchRecommendations() {
                        try {
                            const response = await axios.get('/get-recommendations');
                            this.recommendations = response.data.recommendations;
                        } catch (error) {
                            console.error('Erro ao obter recomendações:', error);
                        }
                    }
                },
                mounted() {
                    this.fetchRecommendations();
                }
            }).mount('#app')
        </script>
    </div>

</body>
</html>
