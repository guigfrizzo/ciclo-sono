# Gradient background with waves

A Pen created on CodePen.io. Original URL: [https://codepen.io/baarbaracrr/pen/KKovmGb](https://codepen.io/baarbaracrr/pen/KKovmGb).

Gradient background with some waves on the bottom of the page. If you want a different background for you website or app this is a simple way. 
Use https://cssgradient.io/ to generate gradients!