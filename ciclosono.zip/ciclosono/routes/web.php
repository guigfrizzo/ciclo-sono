<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SleepCalculatorController;

Route::get('/', [SleepCalculatorController::class, 'index']);
Route::post('/calculate-from-bedtime', [SleepCalculatorController::class, 'calculateFromBedtime']);
Route::post('/calculate-from-wakeup', [SleepCalculatorController::class, 'calculateFromWakeup']);
