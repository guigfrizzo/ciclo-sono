<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Schema;

class DropSessionsTable extends Command
{
    protected $signature = 'sessions:drop';
    protected $description = 'Drop the sessions table';

    public function handle()
    {
        Schema::dropIfExists('sessions');
        $this->info('Sessions table dropped successfully');
    }
}
