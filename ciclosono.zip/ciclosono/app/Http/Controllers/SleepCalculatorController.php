<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;

class SleepCalculatorController extends Controller
{
    private const CYCLE_DURATION = 90; // duração do ciclo em minutos
    private const MIN_CYCLES = 4; // mínimo de ciclos recomendados
    private const MAX_CYCLES = 6; // máximo de ciclos recomendados

    public function index()
    {
        return view('sleep-calculator.index');
    }

    public function calculateFromBedtime(Request $request)
    {
        $request->validate([
            'bedtime' => 'required|date_format:H:i',
        ]);

        $bedtime = Carbon::createFromFormat('H:i', $request->bedtime);
        $wakeupTimes = [];

        // Calcular horários de despertar para 4-6 ciclos
        for ($cycles = self::MIN_CYCLES; $cycles <= self::MAX_CYCLES; $cycles++) {
            $wakeupTime = $bedtime->copy()->addMinutes($cycles * self::CYCLE_DURATION);
            $wakeupTimes[] = [
                'cycles' => $cycles,
                'time' => $wakeupTime->format('H:i'),
                'total_hours' => number_format($cycles * self::CYCLE_DURATION / 60, 1),
            ];
        }

        return response()->json([
            'bedtime' => $bedtime->format('H:i'),
            'wakeup_times' => $wakeupTimes,
        ]);
    }

    public function calculateFromWakeup(Request $request)
    {
        $request->validate([
            'wakeup_time' => 'required|date_format:H:i',
        ]);

        $wakeupTime = Carbon::createFromFormat('H:i', $request->wakeup_time);
        $bedtimes = [];

        // Calcular horários de dormir para 4-6 ciclos
        for ($cycles = self::MIN_CYCLES; $cycles <= self::MAX_CYCLES; $cycles++) {
            $bedtime = $wakeupTime->copy()->subMinutes($cycles * self::CYCLE_DURATION);
            $bedtimes[] = [
                'cycles' => $cycles,
                'time' => $bedtime->format('H:i'),
                'total_hours' => number_format($cycles * self::CYCLE_DURATION / 60, 1),
            ];
        }

        return response()->json([
            'wakeup_time' => $wakeupTime->format('H:i'),
            'bedtimes' => $bedtimes,
        ]);
    }
}
